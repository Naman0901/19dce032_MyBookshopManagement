/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;
/**
 *
 * @author naman
 */
public class Conn {
    Connection c;
    Statement s;
    private JTable table;
    public void con() throws InstantiationException, IllegalAccessException{
    try{
        //Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
        String dbURL2 = "jdbc:derby://localhost:1527/MyBookShop";
            String user = "sa";
            String password = "1234";
            c= DriverManager.getConnection(dbURL2, user, password);
            if (c!= null) {
                System.out.println("Connected to database");
            }
            else{
            s=c.createStatement();
            }
        }   
        catch (SQLException ex)
        {
            System.out.println(ex);
        }
    }
    public int login(String name,String pass) throws InstantiationException, IllegalAccessException
    {
        try {con();
        String sql="select * from SA.\"USERS\" where\"NAME\"='"+name+"' and \"PASSWORD\"='"+pass+"'";
        /*String dbURL2 = "jdbc:derby://localhost:1527/MyBookShop";
            String user = "sa";
            String password = "1234";
            c= DriverManager.getConnection(dbURL2, user, password);*/
            s=c.createStatement();
             ResultSet rs=s.executeQuery(sql);
        
            if(rs.next())
            {
                return 1;
            }
            else{
                return 0;}
        } catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public String frsearch(String name) throws SQLException
    {
        try {
            con();
        } catch (InstantiationException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
        }
        String sql="select * from SA.\"USERS\" where\"NAME\"='"+name+"'";
        s=c.createStatement();
        ResultSet rs=s.executeQuery(sql);
        if (rs.next())
        {
            return rs.getString("que");
        }
        else
        {
            return "no such account exists";
        }
    }
    public String retrive(String user,String ans) throws SQLException, InstantiationException, IllegalAccessException
    {
        con();
        String sql="select * from SA.\"USERS\" where\"ANS\"='"+ans+"' and \"NAME\"='"+user+"'";
        s=c.createStatement();
        ResultSet rs=s.executeQuery(sql);
        if(rs.next())
        {
            //if(user==rs.getString("name"))
                return rs.getString("password");
            /*else
                return "INCORRECT ANSWER";*/
        }
       else
        {
            return "INCORRECT ANSWER";
        }
    }
    public int adduser(String name, String pass) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="select * from SA.\"USERS\" where\"NAME\"='"+name+"' and \"PASSWORD\"='"+pass+"'";
         s=c.createStatement();
             ResultSet rs=s.executeQuery(sql);
        
            if(rs.next())
            {
                return rs.getInt("TYPE");
            }
            else{
                return 0;}
        } 
    catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public int newuser(String name, String pass, String que,String ans,int type) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="insert into SA.\"USERS\"(NAME,PASSWORD,QUE,ANS,TYPE) values('"+name+"','"+pass+"','"+que+"','"+ans+"',"+type+")";
        s=c.createStatement();
             //ResultSet rs=s.executeQuery(sql);
        int i=s.executeUpdate(sql);
            if(i>0)
            {
                return 1;
            }
            else{
                return 0;}
        } 
    catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public ResultSet book() throws InstantiationException, IllegalAccessException
    {
        con();
        try{
            String sql="select * from SA.\"BOOKS\"";
            s=c.createStatement();
            ResultSet rs=s.executeQuery(sql);        
            return rs;
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        
    }
    public int addbook(String id,String name,String isbn,String publisher,String edition,String price,String pages,String author,String copy) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="insert into SA.\"BOOKS\"(ID,NAME,ISBN,AUTHOR,PUBLISHER,EDITION,PAGES,PRICE,COPIES) values('"+id+"','"+name+"','"+isbn+"','"+author+"','"+publisher+"','"+edition+"','"+pages+"','"+price+"','"+copy+"')";
        s=c.createStatement();
        int i=s.executeUpdate(sql);
        if(i>0){return 1;}
        else{return 0;}
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public int updatebook(String id,String name,String isbn,String publisher,String edition,String price,String pages,String author,String copy) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="update SA.\"BOOKS\"set \"NAME\"='"+name+"',\"ISBN\"='"+isbn+"',\"AUTHOR\"='"+author+"',\"PUBLISHER\"='"+publisher+"',\"EDITION\"='"+edition+"',\"PAGES\"='"+pages+"',\"PRICE\"='"+price+"',\"COPIES\"='"+copy+"' where \"ID\" = '"+id+"'";
        s=c.createStatement();
        int i=s.executeUpdate(sql);
        if(i>0){return 1;}
        else{return 0;}
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public int billbook(String id,String name,String price,String copy) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="insert into SA.\"BILL\"(ID,NAME,PRICES,COPIES) values('"+id+"','"+name+"','"+price+"','"+copy+"')";
        s=c.createStatement();
        int i=s.executeUpdate(sql);
        if(i>0){return 1;}
        else{return 0;}
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public ResultSet bill() throws InstantiationException, IllegalAccessException
    {
        con();
        try{
            String sql="select * from SA.\"BILL\"";
            s=c.createStatement();
            ResultSet rs=s.executeQuery(sql);        
            return rs;
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    public int returnbook(String id) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
            String sql="delete from SA.\"BILL\" where \"ID\"='"+id+"'";
            s=c.createStatement();
            //      
            int i=s.executeUpdate(sql);
        if(i>0){return 1;}
        else{return 0;}
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public void copies(String id,String copy) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="update SA.\"BOOKS\" SET \"COPIES\" ='"+copy+"' WHERE \"ID\"='"+id+"'";
        s=c.createStatement();
        int i=s.executeUpdate(sql);
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    public void addcopies(String id,String copy) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="SELECT \"COPIES\" FROM SA.\"BOOKS\" where \"ID\"='"+id+"'";
        s=c.createStatement();
        ResultSet rs=s.executeQuery(sql);  
        if(rs.next())
        {
            int i=rs.getInt("COPIES");
            i=i+Integer.parseInt(copy);
            copies(id,Integer.toString(i));
        }
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    public void clearbill() throws InstantiationException, IllegalAccessException
    {
        con();
        try{
            String sql="delete from SA.\"BILL\"";
            s=c.createStatement();   
            int i=s.executeUpdate(sql);        
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);            
        }
    }
    public int putnote(String head,String note) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="insert into SA.\"NOTES\"(HEAD,NOTE) values('"+head+"','"+note+"')";
        s=c.createStatement();
        int i=s.executeUpdate(sql);
        if(i>0){return 1;}
        else{return 0;}
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public ResultSet getnote() throws InstantiationException, IllegalAccessException
    {
        con();
        try{
            String sql="select * from SA.\"NOTES\"";
            s=c.createStatement();
            ResultSet rs=s.executeQuery(sql);        
            return rs;
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    public int delnote(String head) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
            String sql="delete from SA.\"NOTES\" where \"HEAD\"='"+head+"'";
            s=c.createStatement();
            int i=s.executeUpdate(sql);
        if(i>0){return 1;}
        else{return 0;}
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    public int upnote(String head,String note) throws InstantiationException, IllegalAccessException
    {
        con();
        try{
        String sql="update SA.\"NOTES\" set \"NOTE\"='"+note+"' where \"HEAD\"='"+head+"'";
        s=c.createStatement();
        int i=s.executeUpdate(sql);
        if(i>0){return 1;}
        else{return 0;}
        }
        catch (SQLException ex) {
            Logger.getLogger(Conn.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
}
